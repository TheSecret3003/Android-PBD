package com.example.catsmanager;

public class GetCatActivity {
}
