# IF3111-2019-yeay-Android
# Tugas 1 IF3111 Pengembangan Aplikasi Berbasis Platform
## Mobile Android : Cats Manager

## Deskripsi Singkat
Cat Manager adalah aplikasi yang menunjang produktivitas pengguna. Aplikasi ini memiliki empat utama, yaitu manajemen task pengguna, permainan interaktif untuk refreshing, deteksi kesesuaian suasana untuk menunjang produktivitas, dan fitur yang memfasilitasi pengguna untuk mengatur waktu penggunaan smartphone-nya.

## Anggota Tim
-13516076 Haifa Fadhilla Ilma<br>
-13516127 Muhammmad Azka Widyanto<br>
-13516130 Nadija Herdwina P.S. <br>


Menggunakan Android Studio, dengan bahasa java dan menggunakan database dengan mongoDB<br>

Untuk menjalankan aplikasi, build aplikasi setelah membuka aplikasi android studio,  lalu run app setelah itu. 

Ketika ingin menggunakan aplikasi, user harus login untuk dapat menggunakan aplikasi ini.<br>
Atribut login yang diminta kepada user berupa email dan juga passwordnya. Lalu untuk menggunakan<br>
focus timer, dapat kita atur waktu penggunaan focus timernya, dan juga dapat menggunakan sensor <br>
cahaya untuk menentukan kesesuaian lingkungan belajar. Lalu pada tab kedua kita mempunyai fitur task manager.<br>
Untuk menggunakan task ini kita dapat  menambah task yang sudah ada dan juga menghapus task yang sudah selesai dikerjakan. <br>
Task yang ditampilkan pada fitur ini berupa nama task dan juga tanggal task itu harusnya berakhir.<br>
Lalu pada tab ketiga, terdapat gambar-gambar kucing yang jika gambarnya disentuh akan memunculkan koordinat<br>
dimana user menggunakan focus timmer tersebut, dan pada tampilan dibawah gambar juga terdapat lamanya waktu dalam menggunakan focus timer tersebut.



file resource xml dan java ada pada folder berikut: <br>
- Java : app/src/main/java/com/example/catsmanager
- XML  : app/src/main/res

